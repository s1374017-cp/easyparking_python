import requests
import json
import mysql.connector
from mysql.connector import Error
import logging
from datetime import datetime, timedelta

# 配置日志
logging.basicConfig(level=logging.INFO)

def fetch_and_save_historical_parking_data(start_date, end_date):
    try:
        # 连接到MySQL数据库
        connection = mysql.connector.connect(
            host='127.0.0.1',  # MySQL服务器地址
            user='root',  # 数据库用户名
            password='oscarYE126416()',  # 数据库密码
            database='Eparking_opendata',  # 数据库名称
            charset='utf8mb4',  # 指定字符集
            collation='utf8mb4_unicode_ci'  # 指定排序规则
        )

        if connection.is_connected():
            cursor = connection.cursor()

            # 定义时间间隔（15分钟）
            time_interval = timedelta(minutes=15)

            # 获取数据库中已保存的最大时间
            cursor.execute("SELECT MAX(lastupdate) FROM car_park_historical_info")
            last_saved_time = cursor.fetchone()[0]

            # 如果数据库中有记录，则从上次保存的时间继续
            if last_saved_time:
                logging.info(f"从上次保存的时间继续: {last_saved_time}")
                start_date = last_saved_time + time_interval

            # 遍历日期范围
            current_date = start_date
            while current_date <= end_date:
                # 遍历每天的时间（从0点到23:45，每15分钟一次）
                current_time = datetime(current_date.year, current_date.month, current_date.day, 0, 0)
                while current_time.day == current_date.day:
                    # 如果当前时间小于上次保存的时间，跳过
                    if last_saved_time and current_time <= last_saved_time:
                        current_time += time_interval
                        continue

                    # 拼接API URL
                    time_str = current_time.strftime("%Y%m%d-%H%M")
                    api_url = f"https://api.data.gov.hk/v1/historical-archive/get-file?url=https%3A%2F%2Fresource.data.one.gov.hk%2Ftd%2Fcarpark%2Fvacancy_all.json&time={time_str}"
                    logging.info(f"Fetching data from: {api_url}")

                    # 发送GET请求到API
                    response = requests.get(api_url, timeout=10)
                    response.raise_for_status()

                    # 使用 utf-8-sig 解码响应内容
                    response_text = response.content.decode('utf-8-sig')
                    data = json.loads(response_text)

                    # 处理数据
                    for car_park in data['car_park']:
                        park_id = car_park['park_id']
                        for vehicle in car_park['vehicle_type']:
                            vehicle_type = vehicle['type']
                            for service in vehicle['service_category']:
                                category = service['category']
                                vacancy_type = service['vacancy_type']
                                vacancy = service['vacancy']
                                lastupdate = service['lastupdate']
                                print(f"Park ID: {park_id}, Vehicle Type: {vehicle_type}, Category: {category}, Vacancy: {vacancy}, Last Update: {lastupdate}")

                                # 检查关键字段是否有值
                                required_fields = {
                                    'park_id': park_id,
                                    'lastupdate': lastupdate,
                                    'vehicle_type': vehicle_type,
                                    'service_category': category,
                                    'vacancy_type': vacancy_type,
                                    'vacancy': vacancy
                                }
                                missing_fields = [field for field, value in required_fields.items() if not value]

                                if missing_fields:
                                    logging.warning(f"跳过数据：关键字段缺失或为空。park_id: {park_id}, 缺失字段: {missing_fields}")
                                    continue

                                # 插入数据
                                sql = """
                                INSERT INTO car_park_historical_info (
                                    park_id, lastupdate, vehicle_type, service_category, vacancy_type, vacancy
                                ) VALUES (
                                    %s, %s, %s, %s, %s, %s
                                )
                                ON DUPLICATE KEY UPDATE
                                    vehicle_type = VALUES(vehicle_type),
                                    service_category = VALUES(service_category),
                                    vacancy_type = VALUES(vacancy_type),
                                    vacancy = VALUES(vacancy)
                                """
                                values = (park_id, lastupdate, vehicle_type, category, vacancy_type, vacancy)
                                cursor.execute(sql, values)
                                connection.commit()
                                logging.info(f"成功插入数据: park_id={park_id}, lastupdate={lastupdate}")

                    # 增加15分钟
                    current_time += time_interval

                # 增加一天
                current_date += timedelta(days=1)

            # 关闭游标和连接
            cursor.close()
            connection.close()
            logging.info("数据库连接已关闭")

    except requests.exceptions.HTTPError as http_err:
        logging.error(f"HTTP错误发生: {http_err}")
    except requests.exceptions.ConnectionError as conn_err:
        logging.error(f"连接错误发生: {conn_err}")
    except requests.exceptions.Timeout as timeout_err:
        logging.error(f"请求超时: {timeout_err}")
    except requests.exceptions.RequestException as req_err:
        logging.error(f"请求异常: {req_err}")
    except json.JSONDecodeError as json_err:
        logging.error(f"JSON解析错误: {json_err}")
    except Error as db_err:
        logging.error(f"数据库错误发生: {db_err}")
    except Exception as err:
        logging.error(f"其他错误发生: {err}")

if __name__ == "__main__":
    # 定义日期范围
    start_date = datetime(2025, 2, 22)
    end_date = datetime(2025, 3, 22)

    # 调用函数获取并保存历史停车数据
    fetch_and_save_historical_parking_data(start_date, end_date)