import requests
import json
import socket
import mysql.connector
from mysql.connector import Error, pooling
import logging
from typing import List, Dict, Any, Optional

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class DatabaseManager:
    """数据库连接池管理类"""
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialize()
        return cls._instance

    def _initialize(self):
        self.config = {
            'host': '127.0.0.1',
            'user': 'root',
            'password': 'oscarYE126416()',
            'database': 'Eparking_opendata',
            'charset': 'utf8mb4',
            'collation': 'utf8mb4_unicode_ci',
            'pool_name': 'parking_pool',
            'pool_size': 5,
            'autocommit': True
        }
        try:
            self.connection_pool = pooling.MySQLConnectionPool(**self.config)
            logger.info("数据库连接池初始化成功")
        except Error as e:
            logger.error(f"数据库连接池初始化失败: {e}")
            raise

    def get_connection(self) -> mysql.connector.connection.MySQLConnection:
        """从连接池获取连接"""
        try:
            conn = self.connection_pool.get_connection()
            logger.debug("成功获取数据库连接")
            return conn
        except Error as e:
            logger.error(f"获取数据库连接失败: {e}")
            raise


class RedisCache:
    """Redis缓存模拟类（实际实现需根据Redis库调整）"""

    def __init__(self):
        self.cache = {}

    def update_vacancy(self, park_id: str, vacancy: int, lastupdate: str) -> bool:
        """更新车位缓存"""
        try:
            self.cache[park_id] = {
                'vacancy': vacancy,
                'lastupdate': lastupdate,
                'timestamp': datetime.now().isoformat()
            }
            logger.debug(f"更新缓存成功: park_id={park_id}")
            return True
        except Exception as e:
            logger.error(f"更新缓存失败: {e}")
            return False


class DataValidator:
    """数据验证和标准化类"""

    @staticmethod
    def validate_car_park_data(car_park: Dict[str, Any]) -> Dict[str, Any]:
        """
        验证停车场数据完整性
        Args:
            car_park: 原始停车场数据字典
        Returns:
            验证后的数据字典
        Raises:
            ValueError: 当关键字段缺失时
        """
        required_fields = {
            'park_id': car_park.get('park_id'),
            'lastupdate': car_park.get('lastupdate'),
            'vehicle_type': car_park.get('type'),
            'service_category': car_park.get('category'),
            'vacancy_type': car_park.get('vacancy_type'),
            'vacancy': car_park.get('vacancy')
        }

        missing_fields = [field for field, value in required_fields.items() if value is None]
        if missing_fields:
            raise ValueError(f"关键字段缺失: {missing_fields}")

        return required_fields

    @staticmethod
    def normalize_data_types(data: Dict[str, Any]) -> Dict[str, Any]:
        """
        标准化数据类型
        Args:
            data: 待处理的数据字典
        Returns:
            标准化后的数据字典
        Raises:
            ValueError: 当数据类型转换失败时
        """
        try:
            # 强制类型转换
            data['vacancy'] = int(data['vacancy'])
            # 添加其他需要类型转换的字段
            return data
        except (ValueError, TypeError) as e:
            logger.error(f"数据类型转换失败: {e}")
            raise


class DataStorage:
    """数据存储操作类"""

    def __init__(self, db_manager: DatabaseManager):
        self.db_manager = db_manager
        self.insert_query = """
        INSERT INTO car_park_vacancy_info (
            park_id, lastupdate, vehicle_type, service_category, vacancy_type, vacancy
        ) VALUES (%s, %s, %s, %s, %s, %s)
        ON DUPLICATE KEY UPDATE
            vacancy = VALUES(vacancy),
            lastupdate = VALUES(lastupdate)
        """
        self.batch_size = 50  # 批量插入大小

    def save_data(self, validated_data: Dict[str, Any]) -> bool:
        """
        保存单条验证后的数据
        Args:
            validated_data: 已验证的数据字典
        Returns:
            是否保存成功
        """
        connection = None
        cursor = None
        try:
            connection = self.db_manager.get_connection()
            cursor = connection.cursor()

            values = (
                validated_data['park_id'],
                validated_data['lastupdate'],
                validated_data['vehicle_type'],
                validated_data['service_category'],
                validated_data['vacancy_type'],
                validated_data['vacancy']
            )

            cursor.execute(self.insert_query, values)
            logger.info(f"成功插入数据: park_id={validated_data['park_id']}")
            return True
        except Error as e:
            logger.error(f"数据存储失败: {e}")
            return False
        finally:
            if cursor:
                cursor.close()
            if connection:
                connection.close()

    def batch_save(self, data_list: List[Dict[str, Any]]) -> int:
        """
        批量保存数据
        Args:
            data_list: 数据字典列表
        Returns:
            成功保存的记录数
        """
        success_count = 0
        connection = None
        cursor = None

        try:
            connection = self.db_manager.get_connection()
            cursor = connection.cursor()

            # 分批处理
            for i in range(0, len(data_list), self.batch_size):
                batch = data_list[i:i + self.batch_size]
                values = []

                for data in batch:
                    values.append((
                        data['park_id'],
                        data['lastupdate'],
                        data['vehicle_type'],
                        data['service_category'],
                        data['vacancy_type'],
                        data['vacancy']
                    ))

                try:
                    cursor.executemany(self.insert_query, values)
                    connection.commit()
                    success_count += len(batch)
                    logger.info(f"批量插入成功: 本次插入{len(batch)}条记录")
                except Error as e:
                    connection.rollback()
                    logger.error(f"批量插入失败: {e}")
                    # 尝试单条插入
                    for data in batch:
                        if self.save_data(data):
                            success_count += 1

            return success_count
        except Exception as e:
            logger.error(f"批量保存异常: {e}")
            return success_count
        finally:
            if cursor:
                cursor.close()
            if connection:
                connection.close()


class DataManager:
    """数据管理主类"""

    def __init__(self):
        self.db_manager = DatabaseManager()
        self.validator = DataValidator()
        self.storage = DataStorage(self.db_manager)
        self.cache = RedisCache()

    def process_raw_api_data(self, api_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        处理原始API数据
        Args:
            api_data: API返回的原始JSON数据
        Returns:
            处理后的数据列表
        """
        processed_data = []

        for car_park in api_data.get('car_park', []):
            park_id = car_park.get('park_id')

            for vehicle in car_park.get('vehicle_type', []):
                vehicle_type = vehicle.get('type')

                for service in vehicle.get('service_category', []):
                    try:
                        # 构建数据记录
                        record = {
                            'park_id': park_id,
                            'vehicle_type': vehicle_type,
                            'category': service.get('category'),
                            'vacancy_type': service.get('vacancy_type'),
                            'vacancy': service.get('vacancy'),
                            'lastupdate': service.get('lastupdate')
                        }

                        # 验证和标准化
                        validated = self.validator.validate_car_park_data(record)
                        normalized = self.validator.normalize_data_types(validated)

                        processed_data.append(normalized)

                        # 更新缓存
                        self.cache.update_vacancy(
                            park_id=normalized['park_id'],
                            vacancy=normalized['vacancy'],
                            lastupdate=normalized['lastupdate']
                        )

                    except (ValueError, TypeError) as e:
                        logger.warning(f"数据验证失败，跳过记录: park_id={park_id}, error={e}")
                        continue

        return processed_data

    def process_car_park_data(self, api_data: Dict[str, Any]) -> int:
        """
        处理并保存停车场数据
        Args:
            api_data: API返回的原始JSON数据
        Returns:
            成功保存的记录数
        """
        processed_data = self.process_raw_api_data(api_data)
        saved_count = self.storage.batch_save(processed_data)
        logger.info(f"数据处理完成，成功保存{saved_count}/{len(processed_data)}条记录")
        return saved_count


def check_dns_resolution(host: str) -> bool:
    """检查DNS解析是否正常"""
    try:
        ip_address = socket.gethostbyname(host)
        logger.info(f"成功解析域名 {host} 到IP地址 {ip_address}")
        return True
    except socket.gaierror as e:
        logger.error(f"无法解析域名 {host}: {e}")
        return False


def fetch_api_data(api_url: str) -> Optional[Dict[str, Any]]:
    """
    从API获取数据
    Args:
        api_url: API端点URL
    Returns:
        JSON解析后的数据字典，失败返回None
    """
    try:
        response = requests.get(api_url, timeout=10)
        response.raise_for_status()

        # 处理BOM头
        if response.content.startswith(b'\xef\xbb\xbf'):
            response_text = response.content.decode('utf-8-sig')
        else:
            response_text = response.content.decode('utf-8')

        return json.loads(response_text)
    except requests.exceptions.RequestException as e:
        logger.error(f"API请求失败: {e}")
        return None
    except json.JSONDecodeError as e:
        logger.error(f"JSON解析失败: {e}")
        return None


def fetch_and_save_vacancy_data(api_url: str) -> int:
    """
    获取并保存车位数据主函数
    Args:
        api_url: 数据API的URL
    Returns:
        成功保存的记录数，失败返回-1
    """
    # 检查DNS解析
    host = "resource.data.one.gov.hk"
    if not check_dns_resolution(host):
        return -1

    # 获取API数据
    api_data = fetch_api_data(api_url)
    if not api_data:
        return -1

    # 处理并保存数据
    try:
        data_manager = DataManager()
        saved_count = data_manager.process_car_park_data(api_data)
        return saved_count
    except Exception as e:
        logger.error(f"数据处理异常: {e}")
        return -1


if __name__ == "__main__":
    API_URL = "http://resource.data.one.gov.hk/td/carpark/vacancy_all.json"
    result = fetch_and_save_vacancy_data(API_URL)

    if result >= 0:
        logger.info(f"数据获取和保存完成，共处理{result}条记录")
    else:
        logger.error("数据处理失败")