# predict_vacancy_probability.py
import mysql.connector
import pandas as pd
from datetime import datetime

def predict_probability():
    """
    计算每个车场、每个 15 分钟时段（0-95）未来有空车位的概率：
      P = 历史该时段 vacancy>0 次数 / 历史总采样次数
    将结果写入 car_park_vacancy_probability 表。
    """
    conn = mysql.connector.connect(
        host='127.0.0.1', user='root', password='oscarYE126416()',
        database='Eparking_opendata', charset='utf8mb4'
    )
    # 读取历史数据
    df = pd.read_sql(
        "SELECT park_id, lastupdate, vacancy FROM car_park_historical_info",
        conn, parse_dates=['lastupdate']
    )
    # 计算时段索引：一天 96 个 15 分钟段
    df['slot'] = df['lastupdate'].dt.hour * 4 + df['lastupdate'].dt.minute // 15
    # vacancy>0 视为空位
    df['has_vac'] = df['vacancy'] > 0

    # 分组计算概率
    prob = df.groupby(['park_id','slot'])['has_vac'].mean().reset_index()
    prob.rename(columns={'has_vac':'p_availability'}, inplace=True)

    cursor = conn.cursor()
    # 建表

    # upsert
    upsert = """
    INSERT INTO car_park_vacancy_probability
      (park_id, slot, p_availability, updated_at)
    VALUES (%s, %s, %s, NOW())
    ON DUPLICATE KEY UPDATE
      p_availability = VALUES(p_availability),
      updated_at     = NOW()
    """
    for _, row in prob.iterrows():
        cursor.execute(upsert, (row['park_id'], int(row['slot']), float(row['p_availability'])))
    conn.commit()
    cursor.close()
    conn.close()
    print(f"[{datetime.now()}] Vacancy probability updated.")

if __name__ == "__main__":
    predict_probability()