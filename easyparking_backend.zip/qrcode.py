import qrcode

wifi_config = "WIFI:T:WPA;S:Boorgeel_fisher;P:Iloveamericamorethanchina!;;"
qr = qrcode.QRCode(version=1, box_size=10, border=5)  # 注意是 QRCode 不是 QREcode
qr.add_data(wifi_config)
qr.make(fit=True)
img = qr.make_image(fill_color="black", back_color="white")
img.save("wifi_qr.png")