import requests
import json
import socket
import mysql.connector
from mysql.connector import Error

def fetch_and_save_json(api_url):
    try:
        # 发送GET请求到API
        response = requests.get(api_url, timeout=10)
        response.raise_for_status()

        # 打印调试信息
        print(f"HTTP状态码: {response.status_code}")
        print("响应内容前100个字符:")
        print(response.text[:100])

        # 解析JSON数据
        response_text = response.text
        if response_text.startswith('\ufeff'):  # 检查是否有BOM
            response_text = response_text.lstrip('\ufeff')  # 去除BOM
        data = json.loads(response_text)  # 手动解析JSON
        print("完整的 JSON 数据:")
        #print(json.dumps(data, indent=4))

        # 连接到MySQL数据库
        connection = mysql.connector.connect(
            host='127.0.0.1',  # MySQL服务器地址
            user='root',  # 数据库用户名
            password='oscarYE126416()',  # 数据库密码
            database='Eparking_opendata',  # 数据库名称
            charset='utf8mb4',  # 指定字符集
            collation='utf8mb4_unicode_ci'  # 指定排序规则
        )

        if connection.is_connected():
            cursor = connection.cursor()

            # 遍历JSON数据并插入到数据库
            for item in data['car_park']:
                try:
                    # 提取关键字段
                    park_id = item.get('park_id')
                    name_en = item.get('name_en')
                    name_tc = item.get('name_tc', '')  # 如果为None，替换为空字符串
                    name_sc = item.get('name_sc', '')  # 如果为None，替换为空字符串
                    displayaddress_en = item.get('displayaddress_en', '')
                    displayaddress_tc = item.get('displayaddress_tc', '')  # 如果为None，替换为空字符串
                    displayaddress_sc = item.get('displayaddress_sc', '')  # 如果为None，替换为空字符串

                    # 对非空字符串进行编码和解码
                    if name_tc:
                        name_tc = name_tc.encode('utf-8').decode('unicode_escape')
                    if name_sc:
                        name_sc = name_sc.encode('utf-8').decode('unicode_escape')
                    if displayaddress_tc:
                        displayaddress_tc = displayaddress_tc.encode('utf-8').decode('unicode_escape')
                    if displayaddress_sc:
                        displayaddress_sc = displayaddress_sc.encode('utf-8').decode('unicode_escape')
                    # 检查关键字段是否有值
                    required_fields = {
                        'park_id': park_id
                    }

                    missing_fields = [field for field, value in required_fields.items() if not value]

                    if missing_fields:
                        print(f"跳过数据：关键字段缺失或为空。park_id: {park_id}, 缺失字段: {missing_fields}")
                        continue



                    # 准备SQL插入语句
                    sql = """
                    INSERT INTO car_park_basic_info (
                        park_id, name_en, name_tc, name_sc, displayaddress_en, displayaddress_tc, displayaddress_sc,
                        latitude, longitude, district_en, district_tc, district_sc, contactNo, opening_status,
                        height, remark_en, remark_tc, remark_sc, website_en, website_tc, website_sc, carpark_photo
                    ) VALUES (
                        %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s
                    )
                    """
                    # 提取字段值
                    values = (
                        item.get('park_id'),
                        item.get('name_en'),
                        item.get('name_tc', '').encode('utf-8').decode('utf-8') if item.get('name_tc') else '',
                        item.get('name_sc', '').encode('utf-8').decode('utf-8') if item.get('name_sc') else '',
                        item.get('displayaddress_en', ''),
                        item.get('displayaddress_tc', '').encode('utf-8').decode('utf-8') if item.get(
                            'displayaddress_tc') else '',
                        item.get('displayaddress_sc', '').encode('utf-8').decode('utf-8') if item.get(
                            'displayaddress_sc') else '',
                        item.get('latitude'),
                        item.get('longitude'),
                        item.get('district_en', '').encode('utf-8').decode('utf-8') if item.get('district_en') else '',
                        item.get('district_tc', '').encode('utf-8').decode('utf-8') if item.get('district_tc') else '',
                        item.get('district_sc', ''),
                        item.get('contactNo'),
                        item.get('opening_status'),
                        item.get('height'),
                        item.get('remark_en', ''),
                        item.get('remark_tc', '').encode('utf-8').decode('utf-8') if item.get('remark_tc') else '',
                        item.get('remark_sc', '').encode('utf-8').decode('utf-8') if item.get('remark_sc') else '',
                        item.get('website_en', ''),
                        item.get('website_tc', ''),
                        item.get('website_sc', ''),
                        item.get('carpark_photo')
                    )

                    # 执行SQL语句
                    cursor.execute(sql, values)
                    connection.commit()
                    print(f"成功插入数据: {item.get('park_id')}")

                except Error as e:
                    print(f"插入数据时发生错误: {e}"+"park_id:"+item.get('park_id'))
                    continue

            # 关闭游标和连接
            cursor.close()
            connection.close()
            print("数据库连接已关闭")

    except requests.exceptions.HTTPError as http_err:
        print(f"HTTP错误发生: {http_err}")
    except requests.exceptions.ConnectionError as conn_err:
        print(f"连接错误发生: {conn_err}")
    except requests.exceptions.Timeout as timeout_err:
        print(f"请求超时: {timeout_err}")
    except requests.exceptions.RequestException as req_err:
        print(f"请求异常: {req_err}")
    except json.JSONDecodeError as json_err:
        print(f"JSON解析错误: {json_err}")
    except Exception as err:
        print(f"其他错误发生: {err}")

if __name__ == "__main__":
    api_url = "https://resource.data.one.gov.hk/td/carpark/basic_info_all.json"

    # 验证DNS解析
    try:
        host = "resource.data.one.gov.hk"
        ip_address = socket.gethostbyname(host)
        print(f"成功解析域名 {host} 到IP地址 {ip_address}")
    except socket.gaierror as e:
        print(f"无法解析域名 {host}: {e}")
        exit(1)

    # 调用函数获取并保存JSON数据
    fetch_and_save_json(api_url)