# current_status_updater.py
import requests, json, logging
import mysql.connector
from mysql.connector import Error

logging.basicConfig(level=logging.INFO)

def update_current_status(api_url):
    """每5分钟获取最新 vacancy 并 upsert 到 car_park_current_status 表"""
    try:
        resp = requests.get(api_url, timeout=10)
        resp.raise_for_status()
        data = json.loads(resp.content.decode('utf-8-sig'))

        conn = mysql.connector.connect(
            host='127.0.0.1', user='root', password='oscarYE126416()',
            database='Eparking_opendata', charset='utf8mb4',
            collation='utf8mb4_unicode_ci'
        )
        cursor = conn.cursor()



        upsert = """
        INSERT INTO car_park_current_status
          (park_id, lastupdate, vacancy, updated_at)
        VALUES (%s, %s, %s, NOW())
        ON DUPLICATE KEY UPDATE
          lastupdate = VALUES(lastupdate),
          vacancy    = VALUES(vacancy),
          updated_at = NOW()
        """

        for park in data['car_park']:
            pid = park['park_id']
            # 假设 vacancy_all.json 中每个 service_category 的 vacancy 恰好是车辆总数
            total_vacancy = sum(s['vacancy'] for v in park['vehicle_type'] for s in v['service_category'])
            lastupd = park['vehicle_type'][0]['service_category'][0]['lastupdate']
            cursor.execute(upsert, (pid, lastupd, total_vacancy))

        conn.commit()
        cursor.close()
        conn.close()
        logging.info("car_park_current_status updated.")
    except Exception as e:
        logging.error(f"update_current_status error: {e}")