# scheduler.py
from apscheduler.schedulers.blocking import BlockingScheduler
from datetime import datetime, timedelta

from Parking_info import fetch_and_save_json
from Parking_Vacancy_Data import fetch_and_save_vacancy_data
from Parking_Vacancy_historical_Data import fetch_and_save_historical_parking_data
from current_status_updater import update_current_status

# 基本配置
basic_info_url = "https://resource.data.one.gov.hk/td/carpark/basic_info_all.json"
vacancy_url    = "http://resource.data.one.gov.hk/td/carpark/vacancy_all.json"

sched = BlockingScheduler()

# 1. Parking_info.py：每日 00:00 更新一次
sched.add_job(
    lambda: fetch_and_save_json(basic_info_url),
    trigger='cron', hour=0, minute=0,
    id='job_basic_info'
)

# 2. Parking_Vacancy_Data.py：每 15 分钟更新一次
sched.add_job(
    lambda: fetch_and_save_vacancy_data(vacancy_url),
    trigger='interval', minutes=15,
    id='job_vacancy_data'
)

# 3. Parking_Vacancy_historical_Data.py：每日 01:00 更新一次（采集昨天全部数据）
def job_historical():
    yesterday = datetime.now() - timedelta(days=1)
    fetch_and_save_historical_parking_data(yesterday, yesterday)
sched.add_job(
    job_historical,
    trigger='cron', hour=1, minute=0,
    id='job_historical'
)

# 4. Current status updater：每 5 分钟写入 car_park_current_status
sched.add_job(
    lambda: update_current_status(vacancy_url),
    trigger='interval', minutes=5,
    id='job_current_status'
)

print("Starting scheduler…")
sched.start()