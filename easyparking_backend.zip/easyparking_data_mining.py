import pandas as pd
import mysql.connector
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from prophet import Prophet
from mlxtend.frequent_patterns import apriori, association_rules
from mlxtend.preprocessing import TransactionEncoder

# 数据库配置
DB_CONFIG = {
    'host': '127.0.0.1',
    'user': 'root',
    'password': 'oscarYE126416()',
    'database': 'Eparking_opendata',
    'charset': 'utf8mb4'
}

def connect_mysql():
    return mysql.connector.connect(**DB_CONFIG)

def fetch_parking_data():
    conn = connect_mysql()
    query = """
        SELECT latitude, longitude, HOUR(parking_time) AS hour_of_day
        FROM parking_records
        WHERE latitude IS NOT NULL AND longitude IS NOT NULL
    """
    df = pd.read_sql(query, conn)
    conn.close()
    print(f"[INFO] Loaded {len(df)} parking records.")
    return df

def cluster_high_demand_zones(df):
    print("[INFO] Running KMeans clustering...")
    X = df[['latitude', 'longitude', 'hour_of_day']]
    kmeans = KMeans(n_clusters=5, random_state=42)
    df['cluster'] = kmeans.fit_predict(X)

    plt.figure(figsize=(10, 6))
    plt.scatter(df['longitude'], df['latitude'], c=df['cluster'], cmap='tab10')
    plt.title("Clustered High-Demand Parking Zones")
    plt.xlabel("Longitude")
    plt.ylabel("Latitude")
    plt.grid(True)
    plt.show()

def fetch_time_series_data():
    conn = connect_mysql()
    query = """
        SELECT DATE_FORMAT(parking_time, '%%Y-%%m-%%d %%H:00:00') AS ds,
               COUNT(*) AS y
        FROM parking_records
        GROUP BY ds
        ORDER BY ds
    """
    df = pd.read_sql(query, conn)
    conn.close()
    df['ds'] = pd.to_datetime(df['ds'])
    print(f"[INFO] Loaded {len(df)} hourly time-series records.")
    return df

def forecast_parking_demand(df):
    print("[INFO] Running Prophet forecasting...")
    model = Prophet()
    model.fit(df)

    future = model.make_future_dataframe(periods=168, freq='H')  # 7 days
    forecast = model.predict(future)

    model.plot(forecast)
    plt.title("7-Day Forecast of Parking Demand")
    plt.xlabel("Time")
    plt.ylabel("Estimated Demand")
    plt.show()

def fetch_user_behavior_data():
    conn = connect_mysql()
    query = """
        SELECT user_id, DATE_FORMAT(parking_time, '%%H') AS hour,
               area, is_shared
        FROM parking_records
        WHERE area IS NOT NULL
    """
    df = pd.read_sql(query, conn)
    conn.close()

    # 将行为转为 list 格式以便 Apriori 挖掘
    df['transaction'] = df.apply(lambda x: [f"H:{x['hour']}", f"A:{x['area']}", f"S:{x['is_shared']}"], axis=1)
    transactions = df['transaction'].tolist()

    print(f"[INFO] Loaded {len(transactions)} transactions for association analysis.")
    return transactions

def run_association_rules(transactions):
    print("[INFO] Running Apriori association rule mining...")
    te = TransactionEncoder()
    te_array = te.fit(transactions).transform(transactions)
    df = pd.DataFrame(te_array, columns=te.columns_)

    frequent_items = apriori(df, min_support=0.05, use_colnames=True)
    rules = association_rules(frequent_items, metric="lift", min_threshold=1.2)

    print("\n[Association Rules]")
    print(rules[['antecedents', 'consequents', 'support', 'confidence', 'lift']])

def main():
    # Step 1: 聚类分析
    df_cluster = fetch_parking_data()
    cluster_high_demand_zones(df_cluster)

    # Step 2: 时间序列预测
    df_timeseries = fetch_time_series_data()
    forecast_parking_demand(df_timeseries)

    # Step 3: 关联规则挖掘
    transactions = fetch_user_behavior_data()
    run_association_rules(transactions)

if __name__ == "__main__":
    main()