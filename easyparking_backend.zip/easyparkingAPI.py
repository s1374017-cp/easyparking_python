from flask import Flask, request, jsonify
from flask_cors import CORS
import mysql.connector
from mysql.connector import Error
import jwt
import datetime
from functools import wraps
from werkzeug.security import check_password_hash
from passlib.hash import bcrypt

app = Flask(__name__)
CORS(app, resources={r"/*": {"origins": "*", "methods": ["GET", "POST", "OPTIONS"], "allow_headers": ["Content-Type", "Authorization"]}}, supports_credentials=True)  # 允許跨域

# MySQL 資料庫設定
DB_CONFIG = {
    'host': '127.0.0.1',
    'user': 'root',
    'password': 'oscarYE126416()',
    'database': 'Eparking_opendata',
    'charset': 'utf8mb4',
    'collation': 'utf8mb4_unicode_ci'
}

# 配置JWT密钥（生产环境应该使用更安全的密钥）
app.config['SECRET_KEY'] = 'your-secret-key-here'
# 登录装饰器（用于保护需要认证的路由）
def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.headers.get('Authorization')
        if not token:
            return jsonify({'error': '缺少认证令牌'}), 401

        try:
            data = jwt.decode(token, app.config['SECRET_KEY'], algorithms=['HS256'])
            current_user = data['user']
        except:
            return jsonify({'error': '无效的认证令牌'}), 401

        return f(current_user, *args, **kwargs)
    return decorated

@app.route('/api/login', methods=['POST', 'OPTIONS'])
def login():
    if request.method == 'OPTIONS':
        return '', 200
    """
    用户登录接口
    请求 JSON 格式：
    {
        "username": "...",
        "password": "..."
    }
    回傳 JSON：
    {
        "token": "...",
        "user": {
            "id": ...,
            "username": "...",
            "email": "...",
            "role": "..."
        }
    }
    """
    auth = request.get_json()
    if not auth or not auth.get('username') or not auth.get('password'):
        return jsonify({'error': '缺少用户名或密码'}), 400

    try:
        conn = mysql.connector.connect(**DB_CONFIG)
        cursor = conn.cursor(dictionary=True)

        sql = (
            """
            SELECT user_id AS id, username, email, user_type AS role, password_hash AS password
            FROM users
            WHERE username = %s
            """
        )
        cursor.execute(sql, (auth['username'],))
        user = cursor.fetchone()

        if not user:
            return jsonify({'error': '用户不存在'}), 401

        # 密码验证：支持 bcrypt ($2b/$2y/$2a)、Werkzeug 生成的pbkdf2哈希，以及明文回退
        provided = auth['password']
        stored = (user['password'] or '').strip()
        print(f"[LOGIN DEBUG] username={auth['username']}, stored_prefix={stored[:4]}, provided_len={len(provided)}, stored_len={len(stored)}")
        valid = False
        if stored.startswith(('$2a$', '$2b$', '$2y$', '$2x$')):
            try:
                valid = bcrypt.verify(provided, stored)
                print(f"[LOGIN DEBUG] bcrypt.verify -> {valid}")
            except Exception as e:
                print(f"[LOGIN DEBUG] bcrypt.verify exception: {e}")
                valid = False
        else:
            try:
                valid = check_password_hash(stored, provided)
                print(f"[LOGIN DEBUG] check_password_hash -> {valid}")
            except Exception as e:
                print(f"[LOGIN DEBUG] check_password_hash exception: {e}")
                valid = False
        if not valid and provided != stored:
            return jsonify({'error': '密码错误'}), 401

        # 生成JWT令牌
        token = jwt.encode({
            'user': {
                'id': user['id'],
                'username': user['username'],
                'role': user['role']
            },
            'exp': datetime.datetime.utcnow() + datetime.timedelta(hours=24)
        }, app.config['SECRET_KEY'])

        cursor.close()
        conn.close()

        return jsonify({
            'token': token,
            'user': {
                'id': user['id'],
                'username': user['username'],
                'email': user['email'],
                'role': user['role']
            }
        })

    except Error as e:
        return jsonify({'error': f'資料庫錯誤: {e}'}), 500
    except Exception as e:
        return jsonify({'error': f'伺服器內部錯誤: {e}'}), 500

# 示例受保护的路由
@app.route('/api/protected', methods=['GET'])
@token_required
def protected_route(current_user):
    return jsonify({
        'message': f'欢迎 {current_user["username"]}',
        'user': current_user
    })


@app.route('/nearby', methods=['GET'])
@app.route('/api/nearby', methods=['GET'])
def get_nearby_parking():
    """
    根據傳入的經緯度和半徑，查詢附近停車場的即時車位資訊
    請求參數：
      lat      緯度（必填，浮點數）
      lon      經度（必填，浮點數）
      radius   搜尋半徑，單位公里（可選，預設：1km）
      limit    最大回傳筆數（可選，預設：50）
    回傳 JSON：
      [
        {
          "park_id": "...",
          "name_en": "...",
          "latitude": ...,
          "longitude": ...,
          "distance": ...,
          "vacancies": [
            {
              "vehicle_type": "...",
              "service_category": "...",
              "vacancy_type": "...",
              "vacancy": ...,
              "lastupdate": "..."
            }
          ]
        }
      ]
    """
    try:
        lat = float(request.args.get('lat', ''))
        lon = float(request.args.get('lon', ''))
        print("入參："+str(lat)+"[]"+str(lon))
    except ValueError:
        return jsonify({'error': '缺少或無效的 lat/lon 參數'}), 400

    radius = float(request.args.get('radius', 1.0))
    limit = int(request.args.get('limit', 50))

    try:
        conn = mysql.connector.connect(**DB_CONFIG)
        cursor = conn.cursor(dictionary=True)

        sql = """
        SELECT
            b.park_id,
            b.name_en,
            b.latitude,
            b.longitude,
            v.vehicle_type,
            v.service_category,
            v.vacancy_type,
            v.vacancy,
            v.lastupdate,
            (
              6371 * ACOS(
                COS(RADIANS(%s)) *
                COS(RADIANS(b.latitude)) *
                COS(RADIANS(b.longitude) - RADIANS(%s)) +
                SIN(RADIANS(%s)) *
                SIN(RADIANS(b.latitude))
              )
            ) AS distance
        FROM car_park_basic_info b
        JOIN car_park_vacancy_info v
          ON b.park_id = v.park_id
        JOIN (
          SELECT park_id, MAX(lastupdate) AS maxlu
          FROM car_park_vacancy_info
          GROUP BY park_id
        ) m
          ON v.park_id = m.park_id AND v.lastupdate = m.maxlu
        HAVING distance <= %s
        ORDER BY distance
        LIMIT %s
        """

        params = (lat, lon, lat, radius, limit)
        cursor.execute(sql, params)
        rows = cursor.fetchall()

        parks = {}
        for row in rows:
            pid = row['park_id']
            if pid not in parks:
                parks[pid] = {
                    'park_id': pid,
                    'name_en': row['name_en'],
                    'latitude': row['latitude'],
                    'longitude': row['longitude'],
                    'distance': round(row['distance'], 3),
                    'vacancies': []
                }
            parks[pid]['vacancies'].append({
                'vehicle_type': row['vehicle_type'],
                'service_category': row['service_category'],
                'vacancy_type': row['vacancy_type'],
                'vacancy': row['vacancy'],
                'lastupdate': row['lastupdate']
            })

        cursor.close()
        conn.close()
        print('取得成功1---')
        return jsonify(list(parks.values()))

    except Error as e:
        return jsonify({'error': f'資料庫錯誤: {e}'}), 500
    except Exception as e:
        return jsonify({'error': f'伺服器內部錯誤: {e}'}), 500

@app.route('/search', methods=['GET'])
@app.route('/api/search', methods=['GET'])
def search_parking():
    """
    根據關鍵字搜尋停車場（英文名稱）
    請求參數：
      q   搜尋關鍵字（必填）
    回傳 JSON：
      [
        {
          "park_id": "...",
          "name_en": "...",
          "latitude": ...,
          "longitude": ...
        },
        ...
      ]
    """
    keyword = request.args.get('q', '').strip()
    if not keyword:
        return jsonify({'error': '缺少搜尋參數 q'}), 400

    try:
        conn = mysql.connector.connect(**DB_CONFIG)
        cursor = conn.cursor(dictionary=True)

        sql = """
        SELECT park_id, name_en, latitude, longitude
        FROM car_park_basic_info
        WHERE name_en LIKE %s
        LIMIT 50
        """
        like_pattern = f"%{keyword}%"
        cursor.execute(sql, (like_pattern,))
        rows = cursor.fetchall()

        cursor.close()
        conn.close()
        return jsonify(rows)

    except Error as e:
        return jsonify({'error': f'資料庫錯誤: {e}'}), 500
    except Exception as e:
        return jsonify({'error': f'伺服器內部錯誤: {e}'}), 500

@app.route('/owner/upload_parking_info', methods=['POST'])
@app.route('/api/owner/upload_parking_info', methods=['POST'])
def owner_upload_parking_info():
    """
    車位擁有者上傳車位基本信息及可預約時間段
    請求 JSON 格式：
    {
        "owner_id": "...",
        "parking_info": {
            "location": "...",
            "description": "...",
            "latitude": ...,
            "longitude": ...
        },
        "available_time_slots": [
            {"start": "YYYY-MM-DD HH:MM", "end": "YYYY-MM-DD HH:MM"},
            ...
        ]
    }
    回傳 JSON：
    {"success": true, "message": "上傳成功"}
    """
    data = request.get_json()
    if not data:
        return jsonify({"error": "缺少JSON資料"}), 400

    owner_id = data.get('owner_id')
    parking_info = data.get('parking_info')
    available_time_slots = data.get('available_time_slots')

    if not owner_id or not parking_info or not available_time_slots:
        return jsonify({"error": "缺少必要欄位"}), 400

    try:
        conn = mysql.connector.connect(**DB_CONFIG)
        cursor = conn.cursor()

        # 插入車位基本信息
        insert_parking_sql = """
        INSERT INTO owner_parking_info (owner_id, location, description, latitude, longitude)
        VALUES (%s, %s, %s, %s, %s)
        """
        cursor.execute(insert_parking_sql, (
            owner_id,
            parking_info.get('location'),
            parking_info.get('description'),
            parking_info.get('latitude'),
            parking_info.get('longitude')
        ))
        parking_id = cursor.lastrowid

        # 插入可預約時間段
        insert_time_slot_sql = """
        INSERT INTO owner_parking_time_slots (parking_id, start_time, end_time)
        VALUES (%s, %s, %s)
        """
        for slot in available_time_slots:
            cursor.execute(insert_time_slot_sql, (
                parking_id,
                slot.get('start'),
                slot.get('end')
            ))

        conn.commit()
        cursor.close()
        conn.close()

        return jsonify({"success": True, "message": "上傳成功"})

    except Error as e:
        return jsonify({"error": f"資料庫錯誤: {e}"}), 500

@app.route('/api/driver/available_owner_parkings', methods=['GET'])
def get_available_owner_parkings():
    """
    司機獲取私人上傳的可用車位信息
    請求參數：
      lat      緯度（必填，浮點數）
      lon      經度（必填，浮點數）
      radius   搜尋半徑，單位公里（可選，預設：1km）
    回傳 JSON：
      [
        {
          "parking_id": ..., 
          "owner_id": ..., 
          "location": "...",
          "description": "...",
          "latitude": ..., 
          "longitude": ..., 
          "available_time_slots": [
            {"start_time": "...", "end_time": "..."},
            ...
          ]
        },
        ...
      ]
    """
    try:
        lat = float(request.args.get('lat', ''))
        lon = float(request.args.get('lon', ''))
    except ValueError:
        return jsonify({'error': '缺少或無效的 lat/lon 參數'}), 400

    radius = float(request.args.get('radius', 1.0))

    try:
        conn = mysql.connector.connect(**DB_CONFIG)
        cursor = conn.cursor(dictionary=True)

        sql = """
        SELECT p.parking_id, p.owner_id, p.location, p.description, p.latitude, p.longitude,
               ts.start_time, ts.end_time
        FROM owner_parking_info p
        JOIN owner_parking_time_slots ts ON p.parking_id = ts.parking_id
        WHERE (
          6371 * ACOS(
            COS(RADIANS(%s)) * COS(RADIANS(p.latitude)) * COS(RADIANS(p.longitude) - RADIANS(%s)) +
            SIN(RADIANS(%s)) * SIN(RADIANS(p.latitude))
          )
        ) <= %s
        """

        params = (lat, lon, lat, radius)
        cursor.execute(sql, params)
        rows = cursor.fetchall()

        parkings = {}
        for row in rows:
            pid = row['parking_id']
            if pid not in parkings:
                parkings[pid] = {
                    'parking_id': pid,
                    'owner_id': row['owner_id'],
                    'location': row['location'],
                    'description': row['description'],
                    'latitude': row['latitude'],
                    'longitude': row['longitude'],
                    'available_time_slots': []
                }
            parkings[pid]['available_time_slots'].append({
                'start_time': row['start_time'],
                'end_time': row['end_time']
            })

        cursor.close()
        conn.close()
        return jsonify(list(parkings.values()))

    except Error as e:
        return jsonify({'error': f'資料庫錯誤: {e}'}), 500

@app.route('/api/driver/book_parking', methods=['POST'])
def book_parking():
    """
    司機預約私人車位
    請求 JSON 格式：
    {
      "driver_id": "...",
      "parking_id": ...,
      "start_time": "YYYY-MM-DD HH:MM",
      "end_time": "YYYY-MM-DD HH:MM"
    }
    回傳 JSON：
    {"success": true, "message": "預約成功"}
    """
    data = request.get_json()
    if not data:
        return jsonify({"error": "缺少JSON資料"}), 400

    driver_id = data.get('driver_id')
    parking_id = data.get('parking_id')
    start_time = data.get('start_time')
    end_time = data.get('end_time')

    if not driver_id or not parking_id or not start_time or not end_time:
        return jsonify({"error": "缺少必要欄位"}), 400

    try:
        conn = mysql.connector.connect(**DB_CONFIG)
        cursor = conn.cursor()

        # 檢查時間段是否可用
        check_sql = """
        SELECT COUNT(*) FROM owner_parking_time_slots ts
        LEFT JOIN owner_parking_bookings b ON ts.id = b.time_slot_id
        WHERE ts.parking_id = %s
          AND ts.start_time = %s
          AND ts.end_time = %s
          AND (b.id IS NULL OR (b.end_time <= %s OR b.start_time >= %s))
        """
        cursor.execute(check_sql, (parking_id, start_time, end_time, start_time, end_time))
        (count,) = cursor.fetchone()
        if count == 0:
            return jsonify({"error": "該時間段不可用或已被預約"}), 400

        # 插入預約
        insert_sql = """
        INSERT INTO owner_parking_bookings (driver_id, parking_id, time_slot_id, start_time, end_time)
        VALUES (%s, %s, (
            SELECT id FROM owner_parking_time_slots
            WHERE parking_id = %s AND start_time = %s AND end_time = %s
            LIMIT 1
        ), %s, %s)
        """
        cursor.execute(insert_sql, (driver_id, parking_id, parking_id, start_time, end_time, start_time, end_time))

        conn.commit()
        cursor.close()
        conn.close()

        return jsonify({"success": True, "message": "預約成功"})

    except Error as e:
        return jsonify({"error": f"資料庫錯誤: {e}"}), 500

@app.route('/')
def home():
    return 'Welcome to EasyParking API'

@app.route('/forecast', methods=['GET'])
@app.route('/api/forecast', methods=['GET'])
def forecast():
    park_id = request.args.get('park_id', '').strip()
    if not park_id:
        return jsonify({'error': '缺少 park_id'}), 400

    try:
        conn = mysql.connector.connect(**DB_CONFIG)
        cursor = conn.cursor(dictionary=True)

        sql = (
            """
            SELECT slot, p_availability
            FROM car_park_vacancy_probability
            WHERE park_id = %s
            ORDER BY slot
            """
        )
        cursor.execute(sql, (park_id,))
        rows = cursor.fetchall()

        cursor.close()
        conn.close()

        if not rows:
            return jsonify({'error': '无预测数据'}), 404

        now_slot = (datetime.datetime.utcnow().hour * 4) + (datetime.datetime.utcnow().minute // 15)
        return jsonify({
            'park_id': park_id,
            'now_slot': now_slot,
            'probabilities': [
                {'slot': int(row['slot']), 'p': float(row['p_availability'])}
                for row in rows
            ]
        })

    except Error as e:
        return jsonify({'error': f'資料庫錯誤: {e}'}), 500
    except Exception as e:
        return jsonify({'error': f'伺服器內部錯誤: {e}'}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5001)